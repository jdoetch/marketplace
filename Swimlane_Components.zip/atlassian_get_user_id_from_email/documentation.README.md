This component allows efficient searching of a user by their email address, returning the Jira User ID for seamless 
population of user fields in workflows.

Usage:

- Install the component

- Configure “Jira Admin” asset with Username and Password for a user that has admin privileges to Jira

- Create a playbook for ingestion or utilize an existing playbook

- Configure “email” component input
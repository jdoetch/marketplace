This component allows efficient searching of a user by their email address, returning the Jira User ID for seamless 
population of user fields in workflows.